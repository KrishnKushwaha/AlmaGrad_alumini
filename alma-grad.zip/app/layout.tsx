import "./globals.css"
import { Inter } from "next/font/google"
import { Toaster } from "@/components/ui/toaster"
import Header from "./components/header"
import { usePathname } from "next/navigation"
import type React from "react" // Added import for React

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "AlmaGrad",
  description: "Connect with your alma mater and fellow alumni",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const pathname = usePathname()
  const isLandingPage = pathname === "/"

  return (
    <html lang="en">
      <body className={`${inter.className} ${isLandingPage ? "" : "bg-almagrad-mint bg-opacity-10"}`}>
        {!isLandingPage && <Header />}
        <main className={`${isLandingPage ? "" : "container mx-auto px-4 py-8"}`}>{children}</main>
        <Toaster />
      </body>
    </html>
  )
}

