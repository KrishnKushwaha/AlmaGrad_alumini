import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function LandingPage() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-b from-almagrad-blue to-almagrad-mint text-white">
      <h1 className="text-4xl md:text-6xl font-bold mb-6 text-center">Welcome to AlmaGrad</h1>
      <p className="text-xl md:text-2xl mb-8 text-center max-w-2xl px-4">
        Connect with your alma mater, fellow alumni, and explore new opportunities.
      </p>

      <div className="space-y-6 text-center mb-12">
        <h2 className="text-2xl md:text-3xl font-semibold">How to use AlmaGrad:</h2>
        <ul className="text-lg md:text-xl space-y-2">
          <li>✨ Create your profile and showcase your achievements</li>
          <li>🤝 Network with other alumni and students</li>
          <li>💼 Explore job opportunities shared by the community</li>
          <li>🏫 Stay updated with your alma mater's news and events</li>
        </ul>
      </div>

      <Link href="/home" passHref>
        <Button className="text-almagrad-blue bg-white hover:bg-gray-100 transition-all duration-300 ease-in-out transform hover:scale-105 px-8 py-4 rounded-full text-xl font-semibold shadow-lg">
          Start Your Journey
        </Button>
      </Link>
    </div>
  )
}

