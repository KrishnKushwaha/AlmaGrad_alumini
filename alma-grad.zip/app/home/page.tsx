import NewsFeed from "../components/news-feed"
import MessageCenter from "../components/message-center"

export default function HomePage() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
      <div className="md:col-span-2">
        <h1 className="text-3xl font-bold mb-6 text-almagrad-blue">Welcome to AlmaGrad</h1>
        <NewsFeed />
      </div>
      <div>
        <MessageCenter />
      </div>
    </div>
  )
}

