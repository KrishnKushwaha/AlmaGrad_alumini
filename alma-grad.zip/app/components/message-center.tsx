"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const dummyMessages = [
  { id: 1, sender: "Alice Johnson", message: "Hey, how are you doing?" },
  { id: 2, sender: "Bob Smith", message: "Did you see the latest job posting?" },
  { id: 3, sender: "Charlie Brown", message: "Let's catch up soon!" },
]

export default function MessageCenter() {
  const [messages, setMessages] = useState(dummyMessages)
  const [newMessage, setNewMessage] = useState("")

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (newMessage.trim()) {
      const message = {
        id: messages.length + 1,
        sender: "You",
        message: newMessage,
      }
      setMessages([...messages, message])
      setNewMessage("")
    }
  }

  return (
    <Card className="h-[600px] flex flex-col">
      <CardHeader>
        <CardTitle className="text-almagrad-blue">Message Center</CardTitle>
      </CardHeader>
      <CardContent className="flex-grow overflow-hidden">
        <ScrollArea className="h-full pr-4">
          {messages.map((msg) => (
            <div key={msg.id} className="flex items-start space-x-4 mb-4">
              <Avatar>
                <AvatarImage src="/placeholder.svg" alt={msg.sender} />
                <AvatarFallback>{msg.sender[0]}</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-semibold text-almagrad-blue">{msg.sender}</p>
                <p className="text-sm text-gray-600">{msg.message}</p>
              </div>
            </div>
          ))}
        </ScrollArea>
      </CardContent>
      <CardFooter>
        <form onSubmit={handleSendMessage} className="flex w-full space-x-2">
          <Input
            placeholder="Type a message..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            className="flex-grow"
          />
          <Button type="submit">Send</Button>
        </form>
      </CardFooter>
    </Card>
  )
}

