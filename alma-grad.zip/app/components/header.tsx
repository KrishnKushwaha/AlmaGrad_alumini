"use client"

import React, { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useToast } from "@/components/ui/use-toast"

const Header = () => {
  const pathname = usePathname()
  const router = useRouter()
  const { toast } = useToast()

  const [isAuthenticated, setIsAuthenticated] = useState(true)
  const [userRole, setUserRole] = useState("alumni") // or 'staff'

  const handleLogout = () => {
    // TODO: Implement actual logout logic (e.g., clear tokens, call logout API)
    setIsAuthenticated(false)
    setUserRole("")
    toast({
      title: "Logged out",
      description: "You have been successfully logged out.",
    })
    router.push("/login")
  }

  return (
    <header className="bg-almagrad-blue text-white shadow-md">
      <nav className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/home" className="text-2xl font-bold text-almagrad-mint">
          AlmaGrad
        </Link>
        <div className="space-x-4">
          {isAuthenticated ? (
            <>
              <Link
                href="/home"
                className={`text-almagrad-mint hover:text-white transition-colors ${pathname === "/home" ? "font-semibold" : ""}`}
              >
                Home
              </Link>
              <Link
                href="/communities"
                className={`text-almagrad-mint hover:text-white transition-colors ${pathname === "/communities" ? "font-semibold" : ""}`}
              >
                Communities
              </Link>
              <Link
                href="/jobs"
                className={`text-almagrad-mint hover:text-white transition-colors ${pathname === "/jobs" ? "font-semibold" : ""}`}
              >
                Jobs
              </Link>
              {userRole === "staff" && (
                <Link
                  href="/staff"
                  className={`text-almagrad-mint hover:text-white transition-colors ${pathname.startsWith("/staff") ? "font-semibold" : ""}`}
                >
                  Staff Dashboard
                </Link>
              )}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src="/placeholder.svg" alt="User" />
                      <AvatarFallback>U</AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">User Name</p>
                      <p className="text-xs leading-none text-muted-foreground">user@example.com</p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/profile">Profile</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/settings">Settings</Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>Log out</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            <Button
              asChild
              variant="secondary"
              className="text-almagrad-blue bg-almagrad-mint hover:bg-almagrad-mint/90"
            >
              <Link href="/login">Login / Sign Up</Link>
            </Button>
          )}
        </div>
      </nav>
    </header>
  )
}

export default Header

