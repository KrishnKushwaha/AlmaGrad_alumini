"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { HeartIcon, MessageCircleIcon, ShareIcon } from "lucide-react"

const dummyPosts = [
  {
    id: 1,
    author: "John Doe",
    content: "Just landed a new job at Google! So excited for this new chapter in my career.",
    likes: 42,
    comments: 7,
    shares: 3,
  },
  {
    id: 2,
    author: "Jane Smith",
    content: "Proud to announce that my startup has secured its first round of funding!",
    likes: 89,
    comments: 15,
    shares: 10,
  },
]

export default function NewsFeed() {
  const [posts, setPosts] = useState(dummyPosts)
  const [newPost, setNewPost] = useState("")

  const handlePostSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (newPost.trim()) {
      const post = {
        id: posts.length + 1,
        author: "Current User",
        content: newPost,
        likes: 0,
        comments: 0,
        shares: 0,
      }
      setPosts([post, ...posts])
      setNewPost("")
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="pt-6">
          <form onSubmit={handlePostSubmit}>
            <Textarea
              placeholder="What's on your mind?"
              value={newPost}
              onChange={(e) => setNewPost(e.target.value)}
              className="mb-4"
            />
            <Button type="submit">Post</Button>
          </form>
        </CardContent>
      </Card>
      {posts.map((post) => (
        <Card key={post.id}>
          <CardHeader>
            <div className="flex items-center space-x-4">
              <Avatar>
                <AvatarImage src="/placeholder.svg" alt={post.author} />
                <AvatarFallback>{post.author[0]}</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-semibold text-almagrad-blue">{post.author}</p>
                <p className="text-sm text-gray-500">2 hours ago</p>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <p>{post.content}</p>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button
              variant="ghost"
              size="sm"
              className="text-almagrad-blue hover:text-almagrad-blue hover:bg-almagrad-mint/20"
            >
              <HeartIcon className="w-4 h-4 mr-2" />
              {post.likes}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="text-almagrad-blue hover:text-almagrad-blue hover:bg-almagrad-mint/20"
            >
              <MessageCircleIcon className="w-4 h-4 mr-2" />
              {post.comments}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="text-almagrad-blue hover:text-almagrad-blue hover:bg-almagrad-mint/20"
            >
              <ShareIcon className="w-4 h-4 mr-2" />
              {post.shares}
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}

