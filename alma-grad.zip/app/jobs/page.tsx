"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const dummyJobs = [
  { id: 1, title: "Frontend Developer", company: "TechCorp", location: "New York, NY", type: "Full-time" },
  { id: 2, title: "Data Scientist", company: "DataWiz", location: "San Francisco, CA", type: "Contract" },
  { id: 3, title: "UX Designer", company: "DesignMasters", location: "London, UK", type: "Part-time" },
  { id: 4, title: "Backend Engineer", company: "ServerPros", location: "Berlin, Germany", type: "Full-time" },
]

export default function JobBoardPage() {
  const [jobs, setJobs] = useState(dummyJobs)
  const [searchTerm, setSearchTerm] = useState("")

  const filteredJobs = jobs.filter(
    (job) =>
      job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.company.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Job Board</h1>
      <div className="mb-6">
        <Input placeholder="Search jobs..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
      </div>
      <div className="space-y-6">
        {filteredJobs.map((job) => (
          <Card key={job.id}>
            <CardHeader>
              <CardTitle>{job.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg font-semibold mb-2">{job.company}</p>
              <p className="text-sm text-gray-500 mb-4">{job.location}</p>
              <div className="flex justify-between items-center">
                <Badge>{job.type}</Badge>
                <Button>Apply Now</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

