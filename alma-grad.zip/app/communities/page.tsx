"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const dummyCommunities = [
  { id: 1, name: "Web Development", members: 1250 },
  { id: 2, name: "Game Development", members: 890 },
  { id: 3, name: "Data Science", members: 1500 },
  { id: 4, name: "Entrepreneurship", members: 2000 },
]

export default function CommunitiesPage() {
  const [communities, setCommunities] = useState(dummyCommunities)
  const [searchTerm, setSearchTerm] = useState("")

  const filteredCommunities = communities.filter((community) =>
    community.name.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Communities</h1>
      <div className="mb-6">
        <Input placeholder="Search communities..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCommunities.map((community) => (
          <Card key={community.id}>
            <CardHeader>
              <CardTitle className="flex items-center space-x-4">
                <Avatar>
                  <AvatarImage src={`/placeholder.svg?text=${community.name[0]}`} alt={community.name} />
                  <AvatarFallback>{community.name[0]}</AvatarFallback>
                </Avatar>
                <span>{community.name}</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-500 mb-4">{community.members} members</p>
              <Button className="w-full">Join Community</Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

